package com.example.demo.services;

import com.example.demo.BookRepository;
import com.example.demo.entitie.Book;
import com.example.demo.entitie.CodeException;
import com.example.demo.util.ErrorCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class BookService {

    /*    private static List<Book> list = new ArrayList<Book>();

        static {
            list.add(new Book(1L, "book no. 1", "author of book"));
            list.add(new Book(2L, "book no. 2", "author of book"));
            list.add(new Book(3L, "book no. 3", "author of book"));
            list.add(new Book(4L, "book no. 4", "author of book"));
        }*/
    @Autowired
    BookRepository bookRepository;

    public List<Book> getAllBooks() {
        List<Book> bookList = (List<Book>) bookRepository.findAll();
        return bookList;
    }

    public ResponseEntity<Book> getBookById(Long id) {

        try{
//        Book book = bookRepository.getByBookId(id);
        Book book = bookRepository.findById(id);
        return ResponseEntity.ok().body(book);
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }

    }

    public Book addBook(Book book) {

        bookRepository.save(book);
        return book;
    }

    public Book deleteBookById(long id) {
        try{
            Book address = bookRepository.getByBookId(id);
            if (address == null) {
                throw new CodeException("Invalid book id provided",ErrorCode.InvalidParameter);
            }else if (!address.getId().equals(id)) {
                throw new CodeException("Invalid book id provided", ErrorCode.InvalidParameter);
            }else {bookRepository.delete(address);
                return address;
            }
        }catch (Exception e){
            return null;
        }

    }

    public Book updateBook(Book book, long id) {
/*        return list.stream().map(it -> {
            if (it.getId() == id) {
                //            it.setId(); no update unique ID
                it.setTitle(book.getTitle());
                it.setAuthor(book.getAuthor());
            }
            return it;
        }).collect(Collectors.toList());*/
        return  bookRepository.save(book);

    }
}
