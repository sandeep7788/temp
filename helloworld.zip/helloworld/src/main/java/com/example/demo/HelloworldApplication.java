package com.example.demo;

import com.example.demo.entitie.User;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import java.util.LinkedList;
import java.util.List;

import static com.example.demo.util.Utils.print;

@SpringBootApplication
public class HelloworldApplication {

	public static void main(String[] args) {

		ApplicationContext context= SpringApplication.run(HelloworldApplication.class, args);

//		UserRepository userRepository = context.getBean(UserRepository.class);
/*

//		saveUser(userRepository);

		Iterable<User> byId = userRepository.findAll();
		LinkedList<User> tempList=new LinkedList<>();

		List<User> byName = userRepository.getUserByNativeQuery();
//		print(byName);

//		print(byId.get());




//		saveUser(userRepository);
*/

	}
	private static void saveUser(UserRepository userRepository){
		User user =new User();
		User user1 =new User();
		user.setName("user");
		user.setAbout("about");
		user.setEmail("s.pareek7788@gmail.com");
		user.setEnabled(true);
//		user.setId(1);
		user.setImageUrl("image url");
		user.setPassword("password");
		user.setRole("role");

		List<User> list= List.of(user,user1);
		Iterable<User> listResult=userRepository.saveAll(list);

		listResult.forEach( it->{
//			print(it);
		});
	}
}