package com.example.demo.services;

import com.example.demo.AuthorRepository;
import com.example.demo.BookRepository;
import com.example.demo.entitie.Author;
import com.example.demo.entitie.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class AuthorService {

    @Autowired
    AuthorRepository authRepository;

    public ResponseEntity<Author> getAuthorById(Long id) {

        try{
//        Book book = bookRepository.getByBookId(id);
            Author author = authRepository.findByAuthorId(id);
            return ResponseEntity.ok().body(author);
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }

    }

    public ResponseEntity<Iterable<Author>> getAuthor() {

        try{
//        Book book = bookRepository.getByBookId(id);
            Iterable<Author> author = authRepository.findAll();
            return ResponseEntity.ok().body(author);
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }

    }
}
