package com.example.demo.controller;

import com.example.demo.helper.FileUploadHelper;
import com.example.demo.util.Utils;
import org.hibernate.service.spi.ServiceContributor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import javax.print.ServiceUIFactory;
import java.util.ServiceConfigurationError;

@RestController
public class FileUploadController {

    @Autowired
    private FileUploadHelper fileUploadHelper;

    @PostMapping("/uploadFile")
    public ResponseEntity<String> uploadFile(@RequestParam("file")MultipartFile file){

        Utils.print(file.getSize());
        Utils.print(file.getName());
        Utils.print(file.getContentType());
        Utils.print(file.getOriginalFilename());

        if (file.isEmpty()){
            return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body("Request must contain file.");
        }else if (!file.getContentType().equalsIgnoreCase("image/jpeg")){
            return ResponseEntity.status(HttpStatus.OK).body("please upload jpeg file");
        }else if (file.getSize()<=0){
            return ResponseEntity.status(HttpStatus.OK).body("invalid file");
        }else {
            if (fileUploadHelper.uploadFile(file))
                return ResponseEntity.status(HttpStatus.OK).body(ServletUriComponentsBuilder.fromCurrentContextPath().path("/images/").path(file.getOriginalFilename()).toUriString());
            else return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("something went wrong...");
        }

    }
}
///home/sandeep/Documents/workspace-spring-tool-suite-4-4.13.0.RELEASE/helloworld/src/main/resources/static