package com.example.demo.controller;

import com.example.demo.entitie.Book;
import com.example.demo.services.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class BookController {

    @Autowired
    private BookService bookService;

    @GetMapping("/books")
    @ResponseBody
    public List<Book> getBooks(){
        return bookService.getAllBooks();
    }

    @GetMapping("/bookById/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable("id") Long id){
        return bookService.getBookById(id);
    }

    @GetMapping("/books/{id}")
    public ResponseEntity<Book> getBookById1(@PathVariable("id") Long id){
        return bookService.getBookById(id);
    }

    @PostMapping("/books")
    public Book getBookById(@RequestBody Book book){
        return bookService.addBook(book);
    }

    @DeleteMapping("/books/{id}")
    public Book deleteBookById(@PathVariable long id){
        return bookService.deleteBookById(id);
    }

    @PutMapping("/books/{id}")
    public Book updateBook(@RequestBody Book book,@PathVariable("id") long bookId){
        return bookService.updateBook(book,bookId);
    }
}