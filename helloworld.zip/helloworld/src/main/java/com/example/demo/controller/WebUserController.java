package com.example.demo.controller;

import com.example.demo.util.Utils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/user")
public class WebUserController {

    @RequestMapping(value = "/index", method = RequestMethod.GET)
    public String index(Model model) {
        Utils.print("WebUserController index");
        Utils.print("/index");
        return "user/index";
    }
}