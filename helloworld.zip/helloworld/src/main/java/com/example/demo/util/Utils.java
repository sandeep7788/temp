package com.example.demo.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

import java.util.List;

public class Utils {

    public static void print(String value){
        System.out.println("@@value ------------------------ "+value);
    }
    public static void print(Object value){
        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        try {
            String json = ow.writeValueAsString(value);
            System.out.println("@@list "+json);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }
    static int counter = 0;

    public static void print(List value){
        value.forEach(it->{
            counter++;
            ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
            try {
                String json = ow.writeValueAsString(it);
                print("@@list "+counter+"- "+json);
            } catch (JsonProcessingException e) {
                e.printStackTrace();
                print(e.getMessage());
            }
        });
    }
    public static void print(Iterable value){
        value.forEach(it->{
            System.out.println("@@list "+it);
        });
    }

}
/*sudo /opt/lampp/manager-linux-x64.run
*sudo /etc/init.d/apache2 stop
* sudo /opt/lampp/lampp start*/