package com.example.demo.controller;

import com.example.demo.UserRepository;
import com.example.demo.entitie.Message;
import com.example.demo.entitie.User;
import com.example.demo.util.Utils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.util.Date;
import java.util.List;

@Controller
public class WebController {

    @Autowired
    UserRepository userRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String about(Model model) {

        model.addAttribute("title", "Dynamic title");
        return "home";
    }

    @RequestMapping(value = "/content", method = RequestMethod.GET)
    public String content(Model model) {

        model.addAttribute("name", "User name");
        model.addAttribute("date", new Date().toString());
        Utils.print("content");
//        return "about";
        return "content";
    }

    @RequestMapping(value = "/base", method = RequestMethod.GET)
    public String base(Model model) {

        model.addAttribute("name", "User name");
        model.addAttribute("date", new Date().toString());
        Utils.print("base");
        return "base";
    }

    //handler for include fragment

    //register user by website

    @RequestMapping(value = "/example_loop", method = RequestMethod.GET)
    public String example_loop(Model model) {

        List<String> list = List.of("a", "b", "c", "d");
        model.addAttribute("names", list);

        Utils.print("example_loop");
        return "example_loop";
    }

    @RequestMapping(value = "/signup", method = RequestMethod.GET)
    public String signup(Model model) {

        model.addAttribute("user", new User(0,"","",
                passwordEncoder.encode("password"),"USER",true,"",""));
        return "signup";
    }

//handler for custom login
    @GetMapping("/signin")
    public String signin(Model model){
        model.addAttribute("titile","Custom User Login");
        return "login";
    }


    @RequestMapping(value = "do_register", method = RequestMethod.POST)
    public String registerUser(@Valid @ModelAttribute("user") User user, BindingResult bindingResult,
                               @RequestParam(value = "checkbox_agreement", defaultValue = "false") boolean checkbox_agreement,
                               Model model, HttpSession httpSession) {
        Utils.print("signup " + bindingResult.getModel());
        if (bindingResult.hasErrors()) {
            model.addAttribute("user",user);
//            httpSession.setAttribute("message",new Message("abcd","alert-error"));
            return "signup";
        }
        if (!checkbox_agreement)
            httpSession.setAttribute("message", new Message("please check agree button", "alert-error"));
        else {

            user.setRole("ROLE_USER");
            user.setEnabled(true);
            user.setImageUrl("default.jpg");
            user.setPassword(passwordEncoder.encode(user.getPassword()));
            Utils.print("signup_ " + user);
            userRepository.save(user);
        }
        model.addAttribute("user", user);
        return "signup";
    }
}
