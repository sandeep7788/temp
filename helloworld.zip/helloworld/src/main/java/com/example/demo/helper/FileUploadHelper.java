package com.example.demo.helper;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

@Component
public class FileUploadHelper {

//    public final String UPLOAD_DIR="/home/sandeep/Documents/workspace-spring-tool-suite-4-4.13.0.RELEASE/helloworld/src/main/resources/static/images";
//    public final String UPLOAD_DIR = new ClassPathResource("static/images/").getFile().getAbsolutePath();


    public FileUploadHelper() throws IOException {

    }

    public boolean uploadFile(MultipartFile multipartFile){
        boolean f=false;

        try{

/*            InputStream inputStream = multipartFile.getInputStream();
            byte data[]=new byte[inputStream.available()];
            inputStream.read();

//            write
            FileOutputStream fileOutputStream=new FileOutputStream(UPLOAD_DIR+ File.separator+multipartFile.getOriginalFilename());

            fileOutputStream.write(data);
            fileOutputStream.flush();
            fileOutputStream.close();
            */
            f=true;
//            Files.copy(multipartFile.getInputStream(), Path.of(UPLOAD_DIR+ File.separator+multipartFile.getOriginalFilename()), StandardCopyOption.REPLACE_EXISTING);
        }
        catch (Exception e){

        }
        return f;
    }

}
