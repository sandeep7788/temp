package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@RestController
public class UserController {

    @RequestMapping(value = "/getDetails",method = RequestMethod.POST)
    public String getDetails(){
        return "java is best. devtools.";
    }

}
