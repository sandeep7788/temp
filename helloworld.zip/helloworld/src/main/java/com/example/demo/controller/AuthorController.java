package com.example.demo.controller;

import com.example.demo.entitie.Author;
import com.example.demo.entitie.Book;
import com.example.demo.services.AuthorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AuthorController {

    @Autowired
    private AuthorService authorService;

    @GetMapping("/author/{author_id}")
    public ResponseEntity<Author> getAuthorId(@PathVariable("author_id") Long author_id){
        return authorService.getAuthorById(author_id);
    }

    @GetMapping("/author")
    public ResponseEntity<Iterable<Author>> getAuthorId(){
        return authorService.getAuthor();
    }

}
