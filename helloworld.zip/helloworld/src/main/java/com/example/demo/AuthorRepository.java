package com.example.demo;

import com.example.demo.entitie.Author;
import org.springframework.data.repository.CrudRepository;

public interface AuthorRepository extends CrudRepository<Author, Integer> {

    public Author findByAuthorId(Long author_id);
}
//author_id