package com.example.demo;

import com.example.demo.entitie.Book;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface BookRepository extends CrudRepository<Book,Integer> {

//    Book findById(@Param("book_id") Long recordId);

    @Modifying
    @Query(value = "select u From books u WHERE u.book_id = :book_id",nativeQuery=true)
    public Book getByBookId(@Param("book_id") Long book_id);

    public Book findById(Long book_id);
}
