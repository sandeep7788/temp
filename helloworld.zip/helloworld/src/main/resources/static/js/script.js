//console.log("this is script file");
//alert("me");